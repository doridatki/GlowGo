import { Outlet, useLocation } from "react-router";
import Navigation from "./components/Navigation";

export default function Root() {
  const location = useLocation();

  // Hide navigation on certain pages
  const hideNavigation = ['/provider-registration', '/edit-profile'].includes(location.pathname);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className={hideNavigation ? "flex-1" : "flex-1 pb-20"}>
        <Outlet />
      </div>
      {!hideNavigation && <Navigation />}
    </div>
  );
}
