import { createBrowserRouter } from "react-router";
import Root from "./Root";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
import Search from "./pages/Search";
import ProviderProfile from "./pages/ProviderProfile";
import CustomerProfile from "./pages/CustomerProfile";
import Map from "./pages/Map";
import ProviderRegistration from "./pages/ProviderRegistration";
import EditProfile from "./pages/EditProfile";
import NotFound from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "auth", Component: Auth },
      { path: "search", Component: Search },
      { path: "map", Component: Map },
      { path: "provider/:id", Component: ProviderProfile },
      { path: "profile", Component: CustomerProfile },
      { path: "provider-registration", Component: ProviderRegistration },
      { path: "edit-profile", Component: EditProfile },
      { path: "*", Component: NotFound },
    ],
  },
]);
